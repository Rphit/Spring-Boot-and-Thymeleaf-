# spring-jdbcTemplate-curd
Small example of spring-jdbcTemplate curd example with annotation and XML approach both
